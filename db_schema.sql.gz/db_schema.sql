# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: localhost (MySQL 5.6.17-log)
# Database: vamps2
# Generation Time: 2016-04-20 17:53:51 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table silva_taxonomy_info_per_seq
# ------------------------------------------------------------

DROP TABLE IF EXISTS `silva_taxonomy_info_per_seq`;

CREATE TABLE `silva_taxonomy_info_per_seq` (
  `silva_taxonomy_info_per_seq_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sequence_id` bigint(11) unsigned NOT NULL,
  `silva_taxonomy_id` int(11) unsigned NOT NULL,
  `gast_distance` decimal(7,5) NOT NULL,
  `refssu_id` int(11) unsigned NOT NULL,
  `refssu_count` int(10) unsigned NOT NULL DEFAULT '0',
  `rank_id` tinyint(11) unsigned NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`silva_taxonomy_info_per_seq_id`),
  UNIQUE KEY `sequence_id` (`sequence_id`),
  KEY `refssu_id` (`refssu_id`),
  KEY `sequence_uniq_info_fk_rank_id` (`rank_id`),
  KEY `sequence_uniq_info_fk_taxonomy_id_idx` (`silva_taxonomy_id`),
  KEY `all_ids` (`silva_taxonomy_id`,`gast_distance`,`refssu_id`,`refssu_count`,`rank_id`),
  CONSTRAINT `silva_taxonomy_info_per_seq_ibfk_3` FOREIGN KEY (`sequence_id`) REFERENCES `sequence` (`sequence_id`) ON UPDATE CASCADE,
  CONSTRAINT `silva_taxonomy_info_per_seq_ibfk_1` FOREIGN KEY (`rank_id`) REFERENCES `rank` (`rank_id`) ON UPDATE CASCADE,
  CONSTRAINT `silva_taxonomy_info_per_seq_ibfk_2` FOREIGN KEY (`silva_taxonomy_id`) REFERENCES `silva_taxonomy` (`silva_taxonomy_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
