# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: localhost (MySQL 5.6.17-log)
# Database: vamps2
# Generation Time: 2016-04-18 16:18:14 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table access
# ------------------------------------------------------------

DROP TABLE IF EXISTS `access`;

CREATE TABLE `access` (
  `access_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `project_id` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`access_id`),
  UNIQUE KEY `pid_uid` (`user_id`,`project_id`),
  KEY `project_id` (`project_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `access_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `project` (`project_id`) ON UPDATE CASCADE,
  CONSTRAINT `access_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table annotation
# ------------------------------------------------------------

DROP TABLE IF EXISTS `annotation`;

CREATE TABLE `annotation` (
  `annotation_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) NOT NULL,
  `annotation_name` varchar(16) NOT NULL,
  `annotation_num_value` bigint(20) DEFAULT NULL,
  `annotation_str_value` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`annotation_id`),
  UNIQUE KEY `annotation_id` (`annotation_id`),
  KEY `idx_annotation` (`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table classifier
# ------------------------------------------------------------

DROP TABLE IF EXISTS `classifier`;

CREATE TABLE `classifier` (
  `classifier_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classifier` varchar(32) NOT NULL COMMENT '''RDP'',''GAST''',
  `database` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`classifier_id`),
  UNIQUE KEY `classifier-database` (`classifier`,`database`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table column_controlled_vocabularies
# ------------------------------------------------------------

DROP TABLE IF EXISTS `column_controlled_vocabularies`;

CREATE TABLE `column_controlled_vocabularies` (
  `controlled_vocab_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `column_name` varchar(16) NOT NULL,
  PRIMARY KEY (`controlled_vocab_id`,`column_name`),
  UNIQUE KEY `controlled_vocab_id` (`controlled_vocab_id`),
  KEY `idx_column_controlled_vocabularies_0` (`column_name`),
  KEY `idx_column_controlled_vocabularies_1` (`controlled_vocab_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table column_ontology
# ------------------------------------------------------------

DROP TABLE IF EXISTS `column_ontology`;

CREATE TABLE `column_ontology` (
  `column_ontology_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `column_name` varchar(16) NOT NULL,
  `ontology_short_name` varchar(16) NOT NULL,
  `bioportal_id` int(11) NOT NULL,
  `ontology_branch_id` int(11) NOT NULL,
  PRIMARY KEY (`column_ontology_id`),
  UNIQUE KEY `combine` (`column_name`,`ontology_short_name`),
  KEY `idx_column_ontology_0` (`column_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table controlled_vocab_values
# ------------------------------------------------------------

DROP TABLE IF EXISTS `controlled_vocab_values`;

CREATE TABLE `controlled_vocab_values` (
  `vocab_value_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `controlled_vocab_id` bigint(20) NOT NULL,
  `term` varchar(16) NOT NULL,
  `order_by` varchar(16) NOT NULL,
  `default_item` varchar(16) DEFAULT NULL,
  `term_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`vocab_value_id`),
  UNIQUE KEY `vocab_value_id` (`vocab_value_id`),
  KEY `idx_controlled_vocab_values` (`controlled_vocab_id`),
  KEY `fk_controlled_vocab_values_term_idx` (`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table controlled_vocabularies
# ------------------------------------------------------------

DROP TABLE IF EXISTS `controlled_vocabularies`;

CREATE TABLE `controlled_vocabularies` (
  `controlled_vocab_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `vocab_name` varchar(16) NOT NULL,
  PRIMARY KEY (`controlled_vocab_id`),
  UNIQUE KEY `controlled_vocab_id` (`controlled_vocab_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table custom_metadata_272
# ------------------------------------------------------------

DROP TABLE IF EXISTS `custom_metadata_272`;

CREATE TABLE `custom_metadata_272` (
  `custom_metadata_272_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(11) unsigned NOT NULL,
  `dataset_id` int(11) unsigned NOT NULL,
  `depth_end` varchar(128) DEFAULT NULL,
  `dna_quant` varchar(128) DEFAULT NULL,
  `aux_corrected_sample_depth` varchar(128) DEFAULT NULL,
  `iho_area` varchar(128) DEFAULT NULL,
  `habitat` varchar(128) DEFAULT NULL,
  `depth_start` varchar(128) DEFAULT NULL,
  `aux_daylength` varchar(128) DEFAULT NULL,
  `envo_feature` varchar(128) DEFAULT NULL,
  `domain` varchar(128) DEFAULT NULL,
  `Sampling_date` varchar(128) DEFAULT NULL,
  `aux_sunset_min` varchar(128) DEFAULT NULL,
  `aux_sunrise_hr` varchar(128) DEFAULT NULL,
  `absolute_depth_beta` varchar(128) DEFAULT NULL,
  `sediment_depth_start` varchar(128) DEFAULT NULL,
  `envo_biome` varchar(128) DEFAULT NULL,
  `longhurst_long_name` varchar(128) DEFAULT NULL,
  `Dissolved_Iron_Fe_II` varchar(128) DEFAULT NULL,
  `sample_type` varchar(128) DEFAULT NULL,
  `aux_sunrise_min` varchar(128) DEFAULT NULL,
  `redox_state` varchar(128) DEFAULT NULL,
  `aux_sunset_hr` varchar(128) DEFAULT NULL,
  `aux_modisa_sst` varchar(128) DEFAULT NULL,
  `Sulfate_SO4` varchar(128) DEFAULT NULL,
  `environmental_zone` varchar(128) DEFAULT NULL,
  `aux_corrected_depth` varchar(128) DEFAULT NULL,
  `envo_material` varchar(128) DEFAULT NULL,
  `aux_absolute_depth` varchar(128) DEFAULT NULL,
  `aux_sediment` varchar(128) DEFAULT NULL,
  `sediment_depth_end` varchar(128) DEFAULT NULL,
  `aux_avhrr_sst` varchar(128) DEFAULT NULL,
  `longhurst_zone` varchar(128) DEFAULT NULL,
  `aux_par` varchar(128) DEFAULT NULL,
  `salinity` varchar(128) DEFAULT NULL,
  `Ammonium_NH4` varchar(128) DEFAULT NULL,
  `sample_type_beta` varchar(128) DEFAULT NULL,
  `aux_temperature_t` varchar(128) DEFAULT NULL,
  `aux_apparent_oxygen_utilization_a` varchar(128) DEFAULT NULL,
  `aux_nitrate_n` varchar(128) DEFAULT NULL,
  `aux_bec_simulated_phosphate_um` varchar(128) DEFAULT NULL,
  `aux_bec_simulated_iron_nm` varchar(128) DEFAULT NULL,
  `aux_salinity_s` varchar(128) DEFAULT NULL,
  `aux_phosphate_p` varchar(128) DEFAULT NULL,
  `aux_bec_simulated_nitrate_um` varchar(128) DEFAULT NULL,
  `aux_dissolved_oxygen_o` varchar(128) DEFAULT NULL,
  `aux_modis_k490` varchar(128) DEFAULT NULL,
  `aux_oxygen_saturation_u` varchar(128) DEFAULT NULL,
  `aux_silicate_i` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`custom_metadata_272_id`),
  UNIQUE KEY `unique_key` (`project_id`,`dataset_id`,`depth_end`,`dna_quant`,`aux_corrected_sample_depth`,`iho_area`,`habitat`,`depth_start`,`aux_daylength`,`envo_feature`,`domain`,`Sampling_date`,`aux_sunset_min`,`aux_sunrise_hr`,`absolute_depth_beta`,`sediment_depth_start`),
  KEY `project_id` (`project_id`),
  KEY `dataset_id` (`dataset_id`),
  CONSTRAINT `custom_metadata_272_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `project` (`project_id`) ON UPDATE CASCADE,
  CONSTRAINT `custom_metadata_272_ibfk_2` FOREIGN KEY (`dataset_id`) REFERENCES `dataset` (`dataset_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table custom_metadata_273
# ------------------------------------------------------------

DROP TABLE IF EXISTS `custom_metadata_273`;

CREATE TABLE `custom_metadata_273` (
  `custom_metadata_273_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(11) unsigned NOT NULL,
  `dataset_id` int(11) unsigned NOT NULL,
  `depth_end` varchar(128) DEFAULT NULL,
  `domain` varchar(128) DEFAULT NULL,
  `aux_corrected_sample_depth` varchar(128) DEFAULT NULL,
  `nitrate_nodc_annual` varchar(128) DEFAULT NULL,
  `habitat` varchar(128) DEFAULT NULL,
  `depth_start` varchar(128) DEFAULT NULL,
  `aux_daylength` varchar(128) DEFAULT NULL,
  `envo_feature` varchar(128) DEFAULT NULL,
  `aux_corrected_depth` varchar(128) DEFAULT NULL,
  `nitrate_nodc_monthly` varchar(128) DEFAULT NULL,
  `aux_apparent_oxygen_utilization_a` varchar(128) DEFAULT NULL,
  `Sampling_date` varchar(128) DEFAULT NULL,
  `aux_sunset_min` varchar(128) DEFAULT NULL,
  `aux_sunrise_hr` varchar(128) DEFAULT NULL,
  `aux_nitrate_n` varchar(128) DEFAULT NULL,
  `aux_bec_simulated_phosphate_um` varchar(128) DEFAULT NULL,
  `absolute_depth_beta` varchar(128) DEFAULT NULL,
  `aux_temperature_t` varchar(128) DEFAULT NULL,
  `envo_biome` varchar(128) DEFAULT NULL,
  `aux_bec_simulated_iron_nm` varchar(128) DEFAULT NULL,
  `aux_salinity_s` varchar(128) DEFAULT NULL,
  `longhurst_long_name` varchar(128) DEFAULT NULL,
  `aux_chlo` varchar(128) DEFAULT NULL,
  `sample_type` varchar(128) DEFAULT NULL,
  `aux_sunrise_min` varchar(128) DEFAULT NULL,
  `redox_state` varchar(128) DEFAULT NULL,
  `aux_phosphate_p` varchar(128) DEFAULT NULL,
  `aux_bec_simulated_nitrate_um` varchar(128) DEFAULT NULL,
  `iho_area` varchar(128) DEFAULT NULL,
  `aux_modisa_sst` varchar(128) DEFAULT NULL,
  `environmental_zone` varchar(128) DEFAULT NULL,
  `aux_dissolved_oxygen_o` varchar(128) DEFAULT NULL,
  `envo_material` varchar(128) DEFAULT NULL,
  `aux_absolute_depth` varchar(128) DEFAULT NULL,
  `aux_sunset_hr` varchar(128) DEFAULT NULL,
  `aux_sediment` varchar(128) DEFAULT NULL,
  `temp` varchar(128) DEFAULT NULL,
  `aux_avhrr_sst` varchar(128) DEFAULT NULL,
  `longhurst_zone` varchar(128) DEFAULT NULL,
  `aux_modis_k490` varchar(128) DEFAULT NULL,
  `temperature_nodc_annual` varchar(128) DEFAULT NULL,
  `aux_par` varchar(128) DEFAULT NULL,
  `aux_oxygen_saturation_u` varchar(128) DEFAULT NULL,
  `sample_type_beta` varchar(128) DEFAULT NULL,
  `collection_time` varchar(128) DEFAULT NULL,
  `aux_seawifis_k490` varchar(128) DEFAULT NULL,
  `aux_silicate_i` varchar(128) DEFAULT NULL,
  `Phosphate_PO4` varchar(128) DEFAULT NULL,
  `Silicon` varchar(128) DEFAULT NULL,
  `Ammonium_NH4` varchar(128) DEFAULT NULL,
  `Bact_cell_count` varchar(128) DEFAULT NULL,
  `Nitrate_NO3_Nitrite_NO2` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`custom_metadata_273_id`),
  UNIQUE KEY `unique_key` (`project_id`,`dataset_id`,`depth_end`,`domain`,`aux_corrected_sample_depth`,`nitrate_nodc_annual`,`habitat`,`depth_start`,`aux_daylength`,`envo_feature`,`aux_corrected_depth`,`nitrate_nodc_monthly`,`aux_apparent_oxygen_utilization_a`,`Sampling_date`,`aux_sunset_min`,`aux_sunrise_hr`),
  KEY `project_id` (`project_id`),
  KEY `dataset_id` (`dataset_id`),
  CONSTRAINT `custom_metadata_273_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `project` (`project_id`) ON UPDATE CASCADE,
  CONSTRAINT `custom_metadata_273_ibfk_2` FOREIGN KEY (`dataset_id`) REFERENCES `dataset` (`dataset_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table custom_metadata_274
# ------------------------------------------------------------

DROP TABLE IF EXISTS `custom_metadata_274`;

CREATE TABLE `custom_metadata_274` (
  `custom_metadata_274_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(11) unsigned NOT NULL,
  `dataset_id` int(11) unsigned NOT NULL,
  `depth_end` varchar(128) DEFAULT NULL,
  `domain` varchar(128) DEFAULT NULL,
  `aux_corrected_sample_depth` varchar(128) DEFAULT NULL,
  `iho_area` varchar(128) DEFAULT NULL,
  `habitat` varchar(128) DEFAULT NULL,
  `aux_daylength` varchar(128) DEFAULT NULL,
  `envo_feature` varchar(128) DEFAULT NULL,
  `Sampling_date` varchar(128) DEFAULT NULL,
  `aux_sunset_min` varchar(128) DEFAULT NULL,
  `aux_sunrise_hr` varchar(128) DEFAULT NULL,
  `absolute_depth_beta` varchar(128) DEFAULT NULL,
  `Wind_Speed` varchar(128) DEFAULT NULL,
  `envo_biome` varchar(128) DEFAULT NULL,
  `redox_state` varchar(128) DEFAULT NULL,
  `longhurst_long_name` varchar(128) DEFAULT NULL,
  `aux_chlo` varchar(128) DEFAULT NULL,
  `sample_type` varchar(128) DEFAULT NULL,
  `aux_sunrise_min` varchar(128) DEFAULT NULL,
  `Pressure` varchar(128) DEFAULT NULL,
  `aux_sunset_hr` varchar(128) DEFAULT NULL,
  `depth_start` varchar(128) DEFAULT NULL,
  `environmental_zone` varchar(128) DEFAULT NULL,
  `aux_corrected_depth` varchar(128) DEFAULT NULL,
  `Air_Temperature` varchar(128) DEFAULT NULL,
  `envo_material` varchar(128) DEFAULT NULL,
  `aux_absolute_depth` varchar(128) DEFAULT NULL,
  `aux_sediment` varchar(128) DEFAULT NULL,
  `Irradiance` varchar(128) DEFAULT NULL,
  `temp` varchar(128) DEFAULT NULL,
  `aux_avhrr_sst` varchar(128) DEFAULT NULL,
  `longhurst_zone` varchar(128) DEFAULT NULL,
  `aux_par` varchar(128) DEFAULT NULL,
  `sample_type_beta` varchar(128) DEFAULT NULL,
  `aux_seawifis_k490` varchar(128) DEFAULT NULL,
  `collection_time` varchar(128) DEFAULT NULL,
  `lat_lon` varchar(128) DEFAULT NULL,
  `Total_Phosphorus` varchar(128) DEFAULT NULL,
  `Nitrate_NO3_Nitrite_NO2` varchar(128) DEFAULT NULL,
  `Silicon` varchar(128) DEFAULT NULL,
  `Ammonium_NH4` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`custom_metadata_274_id`),
  UNIQUE KEY `unique_key` (`project_id`,`dataset_id`,`depth_end`,`domain`,`aux_corrected_sample_depth`,`iho_area`,`habitat`,`aux_daylength`,`envo_feature`,`Sampling_date`,`aux_sunset_min`,`aux_sunrise_hr`,`absolute_depth_beta`,`Wind_Speed`,`envo_biome`,`redox_state`),
  KEY `project_id` (`project_id`),
  KEY `dataset_id` (`dataset_id`),
  CONSTRAINT `custom_metadata_274_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `project` (`project_id`) ON UPDATE CASCADE,
  CONSTRAINT `custom_metadata_274_ibfk_2` FOREIGN KEY (`dataset_id`) REFERENCES `dataset` (`dataset_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table custom_metadata_fields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `custom_metadata_fields`;

CREATE TABLE `custom_metadata_fields` (
  `custom_metadata_fields_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(11) unsigned NOT NULL,
  `field_name` varchar(60) NOT NULL DEFAULT '',
  `field_type` varchar(16) NOT NULL DEFAULT 'varchar(128)',
  `example` varchar(128) NOT NULL,
  PRIMARY KEY (`custom_metadata_fields_id`),
  UNIQUE KEY `field_name_project_id` (`field_name`,`project_id`),
  KEY `project_id` (`project_id`),
  CONSTRAINT `custom_metadata_fields_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `project` (`project_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table dataset
# ------------------------------------------------------------

DROP TABLE IF EXISTS `dataset`;

CREATE TABLE `dataset` (
  `dataset_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `dataset` varchar(64) NOT NULL DEFAULT '',
  `dataset_description` varchar(100) NOT NULL DEFAULT '',
  `env_sample_source_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `project_id` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`dataset_id`),
  UNIQUE KEY `dataset_project` (`dataset`,`project_id`),
  KEY `dataset_fk_project_id` (`project_id`),
  KEY `dataset_fk_env_sample_source_id` (`env_sample_source_id`),
  CONSTRAINT `dataset_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `project` (`project_id`) ON UPDATE CASCADE,
  CONSTRAINT `dataset_ibfk_2` FOREIGN KEY (`env_sample_source_id`) REFERENCES `env_sample_source` (`env_sample_source_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table dataset_column_ontology
# ------------------------------------------------------------

DROP TABLE IF EXISTS `dataset_column_ontology`;

CREATE TABLE `dataset_column_ontology` (
  `dataset_column_ontology_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dataset_id` int(10) unsigned NOT NULL,
  `column_ontology` int(10) unsigned NOT NULL,
  PRIMARY KEY (`dataset_column_ontology_id`),
  UNIQUE KEY `all_uniq` (`dataset_id`,`column_ontology`),
  KEY `dataset_column_ontology_fk_column_ontology_id_idx` (`column_ontology`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table dbxref
# ------------------------------------------------------------

DROP TABLE IF EXISTS `dbxref`;

CREATE TABLE `dbxref` (
  `dbxref_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) NOT NULL,
  `dbname` varchar(16) NOT NULL,
  `accession` varchar(16) NOT NULL,
  `description` varchar(16) NOT NULL,
  `xref_type` varchar(16) NOT NULL,
  PRIMARY KEY (`dbxref_id`),
  UNIQUE KEY `dbxref_id` (`dbxref_id`),
  KEY `idx_dbxref` (`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table domain
# ------------------------------------------------------------

DROP TABLE IF EXISTS `domain`;

CREATE TABLE `domain` (
  `domain_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `domain` varchar(300) NOT NULL DEFAULT '',
  PRIMARY KEY (`domain_id`),
  UNIQUE KEY `domain` (`domain`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table env_sample_source
# ------------------------------------------------------------

DROP TABLE IF EXISTS `env_sample_source`;

CREATE TABLE `env_sample_source` (
  `env_sample_source_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `env_source_name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`env_sample_source_id`),
  UNIQUE KEY `env_source_name` (`env_source_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table family
# ------------------------------------------------------------

DROP TABLE IF EXISTS `family`;

CREATE TABLE `family` (
  `family_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `family` varchar(300) NOT NULL DEFAULT '',
  PRIMARY KEY (`family_id`),
  UNIQUE KEY `family` (`family`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table genus
# ------------------------------------------------------------

DROP TABLE IF EXISTS `genus`;

CREATE TABLE `genus` (
  `genus_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `genus` varchar(300) NOT NULL DEFAULT '',
  PRIMARY KEY (`genus_id`),
  UNIQUE KEY `genus` (`genus`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table gg_otu
# ------------------------------------------------------------

DROP TABLE IF EXISTS `gg_otu`;

CREATE TABLE `gg_otu` (
  `gg_otu_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `otu_name` int(10) unsigned DEFAULT NULL,
  `gg_taxonomy_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`gg_otu_id`),
  UNIQUE KEY `all_uniq` (`otu_name`,`gg_taxonomy_id`),
  KEY `gg_otu_fk_gg_taxonomy_id_idx` (`gg_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table gg_taxonomy
# ------------------------------------------------------------

DROP TABLE IF EXISTS `gg_taxonomy`;

CREATE TABLE `gg_taxonomy` (
  `gg_taxonomy_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `domain_id` int(11) unsigned DEFAULT NULL,
  `phylum_id` int(11) unsigned DEFAULT NULL,
  `klass_id` int(11) unsigned DEFAULT NULL,
  `order_id` int(11) unsigned DEFAULT NULL,
  `family_id` int(11) unsigned DEFAULT NULL,
  `genus_id` int(11) unsigned DEFAULT NULL,
  `species_id` int(11) unsigned DEFAULT NULL,
  `strain_id` int(11) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`gg_taxonomy_id`),
  UNIQUE KEY `all_names` (`domain_id`,`phylum_id`,`klass_id`,`order_id`,`family_id`,`genus_id`,`species_id`,`strain_id`),
  KEY `taxonomy_fk_strain_id` (`strain_id`),
  KEY `taxonomy_fk_klass_id` (`klass_id`),
  KEY `taxonomy_fk_family_id` (`family_id`),
  KEY `taxonomy_fk_genus_id` (`genus_id`),
  KEY `taxonomy_fk_order_id` (`order_id`),
  KEY `taxonomy_fk_phylum_id` (`phylum_id`),
  KEY `taxonomy_fk_species_id` (`species_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table klass
# ------------------------------------------------------------

DROP TABLE IF EXISTS `klass`;

CREATE TABLE `klass` (
  `klass_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `klass` varchar(300) NOT NULL DEFAULT '',
  PRIMARY KEY (`klass_id`),
  UNIQUE KEY `klass` (`klass`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table mixs_field_description
# ------------------------------------------------------------

DROP TABLE IF EXISTS `mixs_field_description`;

CREATE TABLE `mixs_field_description` (
  `mixs_field_description_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `column_name` varchar(16) NOT NULL,
  `data_type` varchar(16) NOT NULL,
  `desc_or_value` varchar(16) NOT NULL,
  `definition` varchar(16) NOT NULL,
  `min_length` int(11) DEFAULT NULL,
  `active` int(11) NOT NULL,
  PRIMARY KEY (`mixs_field_description_id`),
  UNIQUE KEY `column_name` (`column_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table oligotype
# ------------------------------------------------------------

DROP TABLE IF EXISTS `oligotype`;

CREATE TABLE `oligotype` (
  `oligotype_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `oligotype_info` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`oligotype_id`),
  UNIQUE KEY `oligotype_info` (`oligotype_info`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table olygotypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `olygotypes`;

CREATE TABLE `olygotypes` (
  `olygotypes_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `olygotype_info` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`olygotypes_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table ontology
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ontology`;

CREATE TABLE `ontology` (
  `ontology_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `shortname` varchar(16) NOT NULL,
  `fully_loaded` smallint(1) NOT NULL,
  `fullname` varchar(16) DEFAULT NULL,
  `query_url` varchar(16) DEFAULT NULL,
  `source_url` varchar(16) DEFAULT NULL,
  `definition` text,
  `load_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `version` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`ontology_id`),
  UNIQUE KEY `ontology_id` (`ontology_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table order
# ------------------------------------------------------------

DROP TABLE IF EXISTS `order`;

CREATE TABLE `order` (
  `order_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order` varchar(300) NOT NULL DEFAULT '',
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `order` (`order`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table phylum
# ------------------------------------------------------------

DROP TABLE IF EXISTS `phylum`;

CREATE TABLE `phylum` (
  `phylum_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `phylum` varchar(300) NOT NULL DEFAULT '',
  PRIMARY KEY (`phylum_id`),
  UNIQUE KEY `phylum` (`phylum`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table project
# ------------------------------------------------------------

DROP TABLE IF EXISTS `project`;

CREATE TABLE `project` (
  `project_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `project` varchar(32) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `project_description` text NOT NULL,
  `rev_project_name` varchar(32) NOT NULL DEFAULT '',
  `funding` varchar(64) NOT NULL DEFAULT '',
  `owner_user_id` int(11) unsigned DEFAULT NULL,
  `public` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`project_id`),
  UNIQUE KEY `project` (`project`),
  UNIQUE KEY `rev_project_name` (`rev_project_name`),
  KEY `project_fk_user_id_idx` (`owner_user_id`),
  CONSTRAINT `project_ibfk_1` FOREIGN KEY (`owner_user_id`) REFERENCES `user` (`user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table rank
# ------------------------------------------------------------

DROP TABLE IF EXISTS `rank`;

CREATE TABLE `rank` (
  `rank_id` tinyint(11) unsigned NOT NULL AUTO_INCREMENT,
  `rank` varchar(32) NOT NULL DEFAULT '',
  `rank_number` tinyint(3) NOT NULL,
  PRIMARY KEY (`rank_id`),
  UNIQUE KEY `rank` (`rank`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table ref_silva_taxonomy_info_per_seq_refhvr_id
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ref_silva_taxonomy_info_per_seq_refhvr_id`;

CREATE TABLE `ref_silva_taxonomy_info_per_seq_refhvr_id` (
  `refhvr_id_id` int(10) unsigned NOT NULL,
  `silva_taxonomy_info_per_seq_id` int(10) unsigned NOT NULL,
  UNIQUE KEY `all_uniq` (`refhvr_id_id`,`silva_taxonomy_info_per_seq_id`),
  KEY `silva_taxonomy_info_per_seq_id_idx` (`silva_taxonomy_info_per_seq_id`),
  KEY `refhvr_id_id_idx` (`refhvr_id_id`),
  CONSTRAINT `ref_silva_taxonomy_info_per_seq_refhvr_id_ibfk_1` FOREIGN KEY (`refhvr_id_id`) REFERENCES `refhvr_id` (`refhvr_id_id`) ON UPDATE CASCADE,
  CONSTRAINT `ref_silva_taxonomy_info_per_seq_refhvr_id_ibfk_2` FOREIGN KEY (`silva_taxonomy_info_per_seq_id`) REFERENCES `silva_taxonomy_info_per_seq` (`silva_taxonomy_info_per_seq_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table refhvr_id
# ------------------------------------------------------------

DROP TABLE IF EXISTS `refhvr_id`;

CREATE TABLE `refhvr_id` (
  `refhvr_id_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `refhvr_id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`refhvr_id_id`),
  UNIQUE KEY `refhvr_id_UNIQUE` (`refhvr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table relationship_type
# ------------------------------------------------------------

DROP TABLE IF EXISTS `relationship_type`;

CREATE TABLE `relationship_type` (
  `relationship_type_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `relationship_type` varchar(16) NOT NULL,
  PRIMARY KEY (`relationship_type_id`),
  UNIQUE KEY `relationship_type_id` (`relationship_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table required_metadata_info
# ------------------------------------------------------------

DROP TABLE IF EXISTS `required_metadata_info`;

CREATE TABLE `required_metadata_info` (
  `required_metadata_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dataset_id` int(11) unsigned NOT NULL,
  `taxon_id` int(11) NOT NULL COMMENT 'Refers to the number assigned to the specific metagenome being sampled:\n  required for all sample submissions e.g. marine metagenome is 408172\n   http://www.ncbi.nlm.nih.gov/Taxonomy/Browser/wwwtax.cgi',
  `description` varchar(100) NOT NULL DEFAULT '' COMMENT 'A description of the sample that can include site, subject, sample matter',
  `common_name` varchar(100) NOT NULL DEFAULT '' COMMENT 'Name of the TAXON_ID e.g. 408172 is marine metagenome',
  `altitude` double NOT NULL COMMENT 'Height above ground or sea in the air (in meters) required for all sample submissions - 0 should be used if sample is not in the air above ground',
  `assigned_from_geo` char(1) NOT NULL COMMENT 'Is the latitude, longitude and elevation assigned from a geographic reference? y or n required for all sample submissions.',
  `collection_date` varchar(10) NOT NULL DEFAULT '' COMMENT 'The day and time of sampling, single point in time using a 24 hour time format required for all sample submissions Date should be in MM/DD/YY format.  Time can be truncated or omitted or entered in a separate column collection_time',
  `depth` double NOT NULL COMMENT 'Depth underground for soil or under water for aquatic samples.  Should be in meters required for all sample submissions, should be in meters',
  `country` varchar(128) NOT NULL COMMENT 'The geographical origin of the sample as defined by the country\n  required for all sample submissions, chosen from the GAZ ontology\n  http://bioportal.bioontology.org/visualize/40651',
  `elevation` int(11) NOT NULL COMMENT 'Height of land above sea level in meters\n  required for all sample submissions, distinguish from altitude which is height above land or sea in the air.',
  `env_biome` varchar(128) NOT NULL COMMENT 'Classification of the location where the sample was obtained\n  required for all sample submissions. The world''s major communities, classified according to the predominant vegetation and characterized by adaptations of organisms to that particular environment\nhttp://www.ebi.ac.uk/ontology-lookup/browse.do?ontName=ENVO',
  `env_feature` varchar(128) NOT NULL COMMENT 'Classification of a specific feature in the biome\n  required for all sample submissions e.g. Was the feature a forest, grassland, agricultural site\n  http://www.ebi.ac.uk/ontology-lookup/browse.do?ontName=ENVO ',
  `env_matter` varchar(128) NOT NULL COMMENT 'Classification of the material being sampled\n  required for all sample submissions e.g. soil, sea water, feces\n  http://www.ebi.ac.uk/ontology-lookup/browse.do?ontName=ENVO',
  `latitude` double NOT NULL COMMENT 'Classification of the site by latitude and longitude in decimal degrees\n  required for all sample submissions. Please convert from GPS co-ordinates  or DD MM SS to decimal degrees\n  http://www.microbio.me/qiime/fusebox.psp?page=tools_geo.psp',
  `longitude` double NOT NULL COMMENT 'Classification of the site by latitude and longitude in decimal degrees\n  required for all sample submissions. Please convert from GPS co-ordinates  or DD MM SS to decimal degrees\n  http://www.microbio.me/qiime/fusebox.psp?page=tools_geo.psp',
  `public` char(1) NOT NULL COMMENT 'Has the sample been published?\n  responses: y/n',
  PRIMARY KEY (`required_metadata_id`),
  UNIQUE KEY `dataset_id_u` (`dataset_id`),
  CONSTRAINT `required_metadata_info_ibfk_1` FOREIGN KEY (`dataset_id`) REFERENCES `dataset` (`dataset_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table sequence
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sequence`;

CREATE TABLE `sequence` (
  `sequence_id` bigint(11) unsigned NOT NULL AUTO_INCREMENT,
  `sequence_comp` longblob,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sequence_id`),
  UNIQUE KEY `sequence_comp` (`sequence_comp`(400))
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table sequence_pdr_info
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sequence_pdr_info`;

CREATE TABLE `sequence_pdr_info` (
  `sequence_pdr_info_id` int(11) NOT NULL AUTO_INCREMENT,
  `dataset_id` int(11) unsigned NOT NULL,
  `sequence_id` bigint(11) unsigned NOT NULL,
  `seq_count` int(11) unsigned NOT NULL COMMENT 'count unique sequence per run / project / dataset = frequency from a file',
  `classifier_id` int(10) unsigned NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sequence_pdr_info_id`),
  UNIQUE KEY `dat_seq_count` (`dataset_id`,`seq_count`,`sequence_id`),
  KEY `sequence_pdr_info_fk_sequence_id` (`sequence_id`),
  KEY `sequence_pdr_info_fk_classifier_id_idx` (`classifier_id`),
  CONSTRAINT `sequence_pdr_info_ibfk_1` FOREIGN KEY (`dataset_id`) REFERENCES `dataset` (`dataset_id`) ON UPDATE CASCADE,
  CONSTRAINT `sequence_pdr_info_ibfk_2` FOREIGN KEY (`sequence_id`) REFERENCES `sequence` (`sequence_id`) ON UPDATE CASCADE,
  CONSTRAINT `sequence_pdr_info_ibfk_3` FOREIGN KEY (`classifier_id`) REFERENCES `classifier` (`classifier_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='sequences uniqued per run / project / dataset';



# Dump of table sequence_uniq_info
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sequence_uniq_info`;

CREATE TABLE `sequence_uniq_info` (
  `sequence_uniq_info_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sequence_id` bigint(11) unsigned NOT NULL,
  `silva_taxonomy_info_per_seq_id` int(11) unsigned DEFAULT NULL,
  `gg_otu_id` int(10) unsigned DEFAULT NULL,
  `oligotype_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sequence_uniq_info_id`),
  UNIQUE KEY `sequence_id` (`sequence_id`),
  KEY `sequence_uniq_info_fk_silva_taxonomy_info_per_seq_id_idx` (`silva_taxonomy_info_per_seq_id`),
  KEY `sequence_uniq_info_fk_gg_otu_id_idx` (`gg_otu_id`),
  KEY `sequence_uniq_info_fk_olygotype_id_idx` (`oligotype_id`),
  CONSTRAINT `sequence_uniq_info_ibfk_1` FOREIGN KEY (`sequence_id`) REFERENCES `sequence` (`sequence_id`) ON UPDATE CASCADE,
  CONSTRAINT `sequence_uniq_info_ibfk_2` FOREIGN KEY (`silva_taxonomy_info_per_seq_id`) REFERENCES `silva_taxonomy_info_per_seq` (`silva_taxonomy_info_per_seq_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table silva_taxonomy
# ------------------------------------------------------------

DROP TABLE IF EXISTS `silva_taxonomy`;

CREATE TABLE `silva_taxonomy` (
  `silva_taxonomy_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `domain_id` int(11) unsigned DEFAULT NULL,
  `phylum_id` int(11) unsigned DEFAULT NULL,
  `klass_id` int(11) unsigned DEFAULT NULL,
  `order_id` int(11) unsigned DEFAULT NULL,
  `family_id` int(11) unsigned DEFAULT NULL,
  `genus_id` int(11) unsigned NOT NULL,
  `species_id` int(11) unsigned DEFAULT NULL,
  `strain_id` int(11) unsigned DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`silva_taxonomy_id`),
  UNIQUE KEY `all_names` (`domain_id`,`phylum_id`,`klass_id`,`order_id`,`family_id`,`genus_id`,`species_id`,`strain_id`),
  KEY `taxonomy_fk_strain_id` (`strain_id`),
  KEY `taxonomy_fk_klass_id` (`klass_id`),
  KEY `taxonomy_fk_family_id` (`family_id`),
  KEY `taxonomy_fk_genus_id` (`genus_id`),
  KEY `taxonomy_fk_order_id` (`order_id`),
  KEY `taxonomy_fk_phylum_id` (`phylum_id`),
  KEY `taxonomy_fk_species_id` (`species_id`),
  CONSTRAINT `silva_taxonomy_ibfk_10` FOREIGN KEY (`strain_id`) REFERENCES `strain` (`strain_id`) ON UPDATE CASCADE,
  CONSTRAINT `silva_taxonomy_ibfk_3` FOREIGN KEY (`genus_id`) REFERENCES `genus` (`genus_id`) ON UPDATE CASCADE,
  CONSTRAINT `silva_taxonomy_ibfk_4` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`domain_id`) ON UPDATE CASCADE,
  CONSTRAINT `silva_taxonomy_ibfk_5` FOREIGN KEY (`family_id`) REFERENCES `family` (`family_id`) ON UPDATE CASCADE,
  CONSTRAINT `silva_taxonomy_ibfk_6` FOREIGN KEY (`klass_id`) REFERENCES `klass` (`klass_id`) ON UPDATE CASCADE,
  CONSTRAINT `silva_taxonomy_ibfk_7` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`) ON UPDATE CASCADE,
  CONSTRAINT `silva_taxonomy_ibfk_8` FOREIGN KEY (`phylum_id`) REFERENCES `phylum` (`phylum_id`) ON UPDATE CASCADE,
  CONSTRAINT `silva_taxonomy_ibfk_9` FOREIGN KEY (`species_id`) REFERENCES `species` (`species_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table silva_taxonomy_info_per_seq
# ------------------------------------------------------------

DROP TABLE IF EXISTS `silva_taxonomy_info_per_seq`;

CREATE TABLE `silva_taxonomy_info_per_seq` (
  `silva_taxonomy_info_per_seq_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `sequence_id` bigint(11) unsigned NOT NULL,
  `silva_taxonomy_id` int(11) unsigned NOT NULL,
  `gast_distance` decimal(7,5) NOT NULL,
  `refssu_id` int(11) unsigned NOT NULL,
  `refssu_count` int(10) unsigned NOT NULL DEFAULT '0',
  `rank_id` tinyint(11) unsigned NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`silva_taxonomy_info_per_seq_id`),
  UNIQUE KEY `sequence_id` (`sequence_id`),
  KEY `refssu_id` (`refssu_id`),
  KEY `sequence_uniq_info_fk_rank_id` (`rank_id`),
  KEY `sequence_uniq_info_fk_taxonomy_id_idx` (`silva_taxonomy_id`),
  KEY `all_ids` (`silva_taxonomy_id`,`gast_distance`,`refssu_id`,`refssu_count`,`rank_id`),
  CONSTRAINT `silva_taxonomy_info_per_seq_ibfk_1` FOREIGN KEY (`rank_id`) REFERENCES `rank` (`rank_id`) ON UPDATE CASCADE,
  CONSTRAINT `silva_taxonomy_info_per_seq_ibfk_2` FOREIGN KEY (`silva_taxonomy_id`) REFERENCES `silva_taxonomy` (`silva_taxonomy_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table species
# ------------------------------------------------------------

DROP TABLE IF EXISTS `species`;

CREATE TABLE `species` (
  `species_id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `species` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`species_id`),
  UNIQUE KEY `species` (`species`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table strain
# ------------------------------------------------------------

DROP TABLE IF EXISTS `strain`;

CREATE TABLE `strain` (
  `strain_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `strain` varchar(300) NOT NULL DEFAULT '',
  PRIMARY KEY (`strain_id`),
  UNIQUE KEY `strain` (`strain`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table term
# ------------------------------------------------------------

DROP TABLE IF EXISTS `term`;

CREATE TABLE `term` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ontology_id` bigint(20) NOT NULL,
  `term_name` varchar(16) NOT NULL,
  `identifier` varchar(16) DEFAULT NULL,
  `definition` varchar(16) DEFAULT NULL,
  `namespace` varchar(16) DEFAULT NULL,
  `is_obsolete` smallint(1) NOT NULL DEFAULT '0',
  `is_root_term` smallint(1) NOT NULL,
  `is_leaf` smallint(1) NOT NULL,
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `term_id` (`term_id`),
  UNIQUE KEY `idx_term` (`ontology_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table term_path
# ------------------------------------------------------------

DROP TABLE IF EXISTS `term_path`;

CREATE TABLE `term_path` (
  `term_path_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subject_term_id` bigint(20) NOT NULL,
  `predicate_term_id` bigint(20) NOT NULL,
  `object_term_id` bigint(20) NOT NULL,
  `ontology_id` bigint(20) NOT NULL,
  `relationship_type_id` int(11) NOT NULL,
  `distance` int(11) DEFAULT NULL,
  PRIMARY KEY (`term_path_id`),
  UNIQUE KEY `term_path_id` (`term_path_id`),
  KEY `idx_term_path` (`ontology_id`),
  KEY `idx_term_path_relatonship` (`relationship_type_id`),
  KEY `idx_term_path_subject` (`subject_term_id`),
  KEY `idx_term_path_predicate` (`predicate_term_id`),
  KEY `idx_term_path_object` (`object_term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table term_relationship
# ------------------------------------------------------------

DROP TABLE IF EXISTS `term_relationship`;

CREATE TABLE `term_relationship` (
  `term_relationship_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subject_term_id` bigint(20) NOT NULL,
  `predicate_term_id` bigint(20) NOT NULL,
  `object_term_id` bigint(20) NOT NULL,
  `ontology_id` bigint(20) NOT NULL,
  PRIMARY KEY (`term_relationship_id`),
  UNIQUE KEY `term_relationship_id` (`term_relationship_id`),
  KEY `idx_term_relationship_subject` (`subject_term_id`),
  KEY `idx_term_relationship_predicate` (`predicate_term_id`),
  KEY `idx_term_relationship_object` (`object_term_id`),
  KEY `idx_term_relationship_ontology` (`ontology_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table term_synonym
# ------------------------------------------------------------

DROP TABLE IF EXISTS `term_synonym`;

CREATE TABLE `term_synonym` (
  `synonym_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) NOT NULL,
  `synonym_value` varchar(16) NOT NULL,
  `synonym_type_id` bigint(20) NOT NULL,
  PRIMARY KEY (`synonym_id`),
  UNIQUE KEY `synonym_id` (`synonym_id`),
  KEY `idx_term_synonym` (`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) DEFAULT NULL,
  `email` varchar(64) NOT NULL DEFAULT '',
  `institution` varchar(128) DEFAULT NULL,
  `first_name` varchar(20) DEFAULT NULL,
  `last_name` varchar(20) DEFAULT NULL,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `security_level` tinyint(3) unsigned NOT NULL DEFAULT '50',
  `encrypted_password` varchar(255) NOT NULL DEFAULT '',
  `sign_in_count` int(11) DEFAULT '0',
  `current_sign_in_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `last_sign_in_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `contact_email_inst` (`first_name`,`last_name`,`email`,`institution`),
  UNIQUE KEY `username` (`username`),
  KEY `institution` (`institution`(15))
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table user_project_status
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user_project_status`;

CREATE TABLE `user_project_status` (
  `user_project_status_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `project_id` int(11) unsigned NOT NULL,
  `status` varchar(20) DEFAULT NULL,
  `message` varchar(128) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_project_status_id`),
  UNIQUE KEY `all_uniq` (`user_id`,`project_id`,`status`),
  KEY `project_id_idx` (`project_id`),
  CONSTRAINT `project_id` FOREIGN KEY (`project_id`) REFERENCES `project` (`project_id`) ON UPDATE CASCADE,
  CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
